# Threes-Demo
Basic Environment for Game Threes! (Demo)<br>
<p>
Computer Games and Intelligence (CGI) Lab, NCTU, Taiwan<br>
http://www.aigames.nctu.edu.tw/<br>
  
GitHub URL
https://github.com/Lafeir/HW_0410155.git

<p># HW_0410155
